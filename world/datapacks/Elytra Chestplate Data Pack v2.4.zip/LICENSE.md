# License

You may not distribute, disseminate, copy, publish, reproduce, or sell in any form without express permission. I do not make any express or implied warranty or guarantee for the functions provided by the data package and module. I am not responsible for world damage, software conflicts or other problems caused during use. The user is solely responsible.

All Rights Reserved  
Copyright (c) 2023-2025 vipvincent

# 授權條款

未經明確許可，您不得以任何形式分發、散播、複製、發布、轉載、銷售。  
本人不對資料包和模組提供的功能作出任何明示或暗示的保證或擔保，使用過程中造成世界損壞、軟體衝突或其他問題進行負責，使用者因自行負責。  

All Rights Reserved  
Copyright (c) 2023-2025 vipvincent  